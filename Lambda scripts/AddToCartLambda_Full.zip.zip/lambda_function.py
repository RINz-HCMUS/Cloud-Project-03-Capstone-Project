
import json
import requests
from requests.auth import HTTPBasicAuth
import os

WOOCOMMERCE_URL = os.environ['WOOCOMMERCE_URL']
CONSUMER_KEY = os.environ['CONSUMER_KEY']
CONSUMER_SECRET = os.environ['CONSUMER_SECRET']

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])

        product_id = body['product_id']
        quantity = body.get('quantity', 1)

        url = f"{WOOCOMMERCE_URL}/wp-json/wc/store/cart/add-item"

        payload = {
            "id": product_id,
            "quantity": quantity
        }

        response = requests.post(url, 
                                 json=payload,
                                 auth=HTTPBasicAuth(CONSUMER_KEY, CONSUMER_SECRET),
                                 headers={'Content-Type': 'application/json'})

        if response.status_code in [200, 201]:
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Product added to cart successfully', 'response': response.json()})
            }
        else:
            return {
                'statusCode': response.status_code,
                'body': json.dumps({'message': 'Failed to add product', 'error': response.text})
            }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Internal Server Error', 'error': str(e)})
        }
