import json
import requests
from requests.auth import HTTPBasicAuth
import os

WOOCOMMERCE_URL = os.environ['WOOCOMMERCE_URL']
CONSUMER_KEY = os.environ['CONSUMER_KEY']
CONSUMER_SECRET = os.environ['CONSUMER_SECRET']

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])

        customer_name = body['customer_name']
        customer_email = body['customer_email']
        address = body['address']
        payment_method = body.get('payment_method', 'cod')  # default
        cart_items = body['cart_items']

        order_data = {
            "payment_method": payment_method,
            "payment_method_title": "Cash on Delivery" if payment_method == "cod" else payment_method,
            "set_paid": False,
            "billing": {
                "first_name": customer_name,
                "email": customer_email,
                "address_1": address
            },
            "shipping": {
                "first_name": customer_name,
                "address_1": address
            },
            "line_items": [
                {
                    "product_id": item['product_id'],
                    "quantity": item['quantity']
                } for item in cart_items
            ]
        }

        response = requests.post(
            f"{WOOCOMMERCE_URL}/wp-json/wc/v3/orders",
            auth=HTTPBasicAuth(CONSUMER_KEY, CONSUMER_SECRET),
            json=order_data,
            headers={'Content-Type': 'application/json'}
        )

        if response.status_code in [200, 201]:
            return {
                "statusCode": 200,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type"
                },
                "body": json.dumps({'message': 'Order placed successfully', 'order': response.json()})
            }
        else:
            return {
                "statusCode": response.status_code,
                "body": json.dumps({'message': 'Failed to place order', 'error': response.text})
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({'message': 'Internal Server Error', 'error': str(e)})
        }
